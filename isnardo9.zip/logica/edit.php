<?php
include('conexion.php');
include("user.php");
include('session.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM reporte WHERE id = $id";
    $result = mysqli_query($conexion, $query);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $sector = $row['sector'];
        $producto = $row['producto'];
        $lote = $row['lote'];
        $codigo_barra = $row['codigo_barra'];
        $precio = $row['precio'];
        $caducidad = $row['caducidad'];
        $cantidad = $row['cantidad'];
    }
}
if (isset($_POST['guardado'])) {
    $id = $_GET['id'];
    $sector = $_POST['sector'];
    $producto = $_POST['producto'];
    $lote = $_POST['lote'];
    $codigo_barra = $_POST['codigo_barra'];
    $precio = $_POST['precio'];
    $caducidad = $_POST['caducidad'];
    $cantidad = $_POST['cantidad'];

    $query = "UPDATE reporte SET sector = '$sector', producto = '$producto', lote = '$lote', codigo_barra = '$codigo_barra', precio = '$precio', caducidad = '$caducidad', cantidad = '$cantidad' WHERE id = $id";
    mysqli_query($conexion, $query);
    header('Location: dashboard.php');

}

?>
<?php
include('dashlayout.php');

$conexion = mysqli_connect("localhost","root","","db_isnardo");
$query = "SELECT * FROM sectores";
$resultado = mysqli_query($conexion, $query);

$municipios = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $municipios[$row['municipio']][] = $row;
}
?>



<form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST"  class="ad-form">
<label for="sector">Hubicación:</label>

<select name="sector" class="mirad" required>
    <option value="">Seleccione un sector</option>
    <?php foreach($municipios as $municipio => $opciones): ?>
        <optgroup label="<?php echo htmlspecialchars($municipio); ?>">
            <?php foreach($opciones as $opcion): ?>
                <option value="<?php echo htmlspecialchars($municipio.' - '.$opcion['centropopular']); ?>">
                    <?php echo htmlspecialchars($opcion['sector'].' - '.$opcion['centropopular']); ?>
                </option>
            <?php endforeach; ?>
        </optgroup>
    <?php endforeach; ?>
</select>
<br class="labelspace">
<label for="producto">Nombre de Producto:</label>
<input type="text" name="producto" id="" placeholder="Nombre de Producto" class="formu" value="<?php echo $producto; ?>">

<br class="labelspace">
<label for="lote">Lote:</label>
<input type="text" name="lote" id="" placeholder="Lote" oninput="this.value = this.value.toUpperCase()" class="formu" value="<?php echo $lote; ?>">
<br class="labelspace">
<label for="codigo_barra">Código de Barras:</label>
<input type="text" name="codigo_barra" id="" placeholder="Código de Barra" oninput="this.value = this.value.toUpperCase()" class="formu" value="<?php echo $codigo_barra; ?>">
<br class="labelspace">
<label for="precio">Precio:</label>
<input type="number" name="precio" id="" placeholder="Precio" class="formu" value="<?php echo $precio; ?>">
<br class="labelspace">
<label for="caducidad">Caducidad:</label>
<input type="date" name="caducidad" id="" class="formu" value="<?php echo $caducidad; ?>">
<br class="labelspace">
<label for="cantidad">Cantidad:</label>
<input type="number" min="1" name="cantidad" id="" placeholder="Cantidad" class="formu" value="<?php echo $cantidad; ?>">
<br class="labelspace">

<br class="salto">

<div class="editdeletbtn">
<td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td>
    <div class="editbtn">
        <!--<td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td> -->
        <input type="submit" name="guardado" value="Guardar Cambios" class="submit">
        <button type="button" onclick="history.back()" style="background-color: #f00; color: #fff; padding: 7px; border-radius: 7px; font-weight: 700;" >Cancelar</button>
    </div>
</div>
</form>
