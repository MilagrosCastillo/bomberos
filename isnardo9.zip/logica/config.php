<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración</title>
<?php
// Iniciar sesión si no está iniciada
if (!isset($_SESSION)) {
    session_start();
}

// Incluir archivos necesarios
include('dashlayout.php');
include('conexion.php');
include('session.php');

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    die("Acceso denegado. Por favor, inicie sesión.");
}

$varusuario = $_SESSION['usuario'];

// Obtener información del usuario
$query = "SELECT * FROM usuarios WHERE usuario = ?";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "s", $varusuario);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($resultado) == 1) {
    $row = mysqli_fetch_array($resultado);
    $usuario = $row['usuario'];
    $password = $row['password']; // Contraseña encriptada en la base de datos
}

// Procesar actualización de configuración
if (isset($_POST['config'])) {
    $usuario = $_POST['usuario'];
    $password_plain = $_POST['password']; // Contraseña en texto plano desde el formulario

    // Encriptar la contraseña antes de guardarla en la base de datos
    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    $query2 = "UPDATE usuarios SET usuario = ?, password = ? WHERE usuario = ?";
    $stmt2 = mysqli_prepare($conexion, $query2);
    mysqli_stmt_bind_param($stmt2, "sss", $usuario, $password_hashed, $varusuario);
    mysqli_stmt_execute($stmt2);

    if (mysqli_stmt_affected_rows($stmt2) > 0) {
        $_SESSION['usuario'] = $usuario; // Actualizar la sesión con el nuevo nombre de usuario
        echo "Configuración actualizada correctamente.";
    } else {
        echo "Error al actualizar la configuración.";
    }
}
?>
</head>
<body>

<form action="config.php" method="post" class="configcenter">
    <label for="usuario">Nombre de Usuario:</label>
    <input type="text" name="usuario" class="formu" value="<?php echo $usuario;?>" autocomplete="false">
    <br class="labelspace">
    <label for="password">Ingrese Nueva Contraseña:</label>
    <input type="password" name="password" class="formu" id="pass" autocomplete="false">
    <label for="password" id="view" style="display: block; cursor: pointer;"><i class="fa-solid fa-eye"></i> Mostrar contraseña</label>
    <label for="password" id="notview" style="display: none; cursor: pointer;"><i class="fa-solid fa-eye-slash"></i> Ocultar contraseña</label>
    <br class="labelspace">
    <br>
    <input type="submit" name="config" style="margin: 0;" class="submit" value="Guardar Nuevos Cambios">
</form>

<script src="./js/vew.js"></script>
    
</body>
</html>
