<?php 

include("conexion.php");
include("session.php");

include("user.php");

$varusuario = $_SESSION["usuario"];
// $head = "<div class='mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8'><center><h1 class='text-3xl font-bold tracking-tight text-gray-900'>Bienvenido $varusuario al Resumen</h1></center></div>";
$activa1 = true;
include('dashlayout.php');

?>
<style>
th{
    padding: 21px;
    border: 1px solid;
    margin-top: 7%;
    text-align: center;
}
td{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
</style>



<form class="mt-10 mx-auto max-w-xl py-2 px-6 mb-7 rounded-full bg-gray-50 border flex focus-within:border-blue-900" method="get" action="search.php">
    <input type="text" placeholder="Realizar Busqueda" class="bg-transparent w-full focus:outline-none pr-4 border-0 focus:ring-0 px-0 py-0" name="busqueda">
    <button type="submit" name="search" class="flex flex-row items-center justify-center min-w-[130px] px-4 rounded-full font-medium tracking-wide border disabled:cursor-not-allowed disabled:opacity-50 transition ease-in-out duration-150 text-base bg-blue-900 text-white font-medium tracking-wide border-transparent py-1.5 h-[38px] -mr-3" >Buscar<i class="fa-solid fa-magnifying-glass ml-3"></i></button>
</form>
<div class="btn-pdf-div">
  <a href="pdf-resumen.php?search=<?php echo urlencode($_GET['busqueda'] ?? ''); ?>" target="_blank">
    <button class="btn-pdf" name="ver">
      Descargar Resumen en PDF <i class="fa-solid fa-download"></i>
    </button>
  </a>
</div>

<?php
// Verificar rol (ejemplo para superadmin)
if ($_SESSION["rol"] === 'superadmin') {
    // Mostrar funcionalidades completas
    include('searchsuperadmin.php');
} else {
    // Limitar funcionalidades
    include('searchadmin.php');
}
?>



