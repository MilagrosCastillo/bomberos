<?php
include("session.php");
$activa = true;

//error_reporting(0);


include("dashlayout.php");

include("conexion.php");
//include("user.php");

include("user.php");
$varusuario = $_SESSION["usuario"];

?>

<?php
$conexion = mysqli_connect("localhost","root","","db_isnardo");
$query = "SELECT * FROM sectores";
$resultado = mysqli_query($conexion, $query);

$municipios = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $municipios[$row['municipio']][] = $row;
}
?>

<?phpif(!isset($_SESSION)){session_start();}?>


<!--<div class="btn-res-re"><div class="ad-form">
    <a href="dashboard.php"><button class="btn-re"><i class="fa-solid fa-arrow-left"></i> Regresar</button></a>
</div>


<br style="margin-top: 14px;">
-->

<form action="guardado.php" method="POST" id="ad_form" class="ad-form">
<select name="sector" required>
    <option value="">Seleccione un sector</option>
    <?php foreach($municipios as $municipio => $opciones): ?>
        <optgroup label="<?php echo htmlspecialchars($municipio); ?>">
            <?php foreach($opciones as $opcion): ?>
                <option value="<?php echo htmlspecialchars($municipio.' - '.$opcion['centropopular']); ?>">
                    <?php echo htmlspecialchars($opcion['sector'].' - '.$opcion['centropopular']); ?>
                </option>
            <?php endforeach; ?>
        </optgroup>
    <?php endforeach; ?>
</select>
<input type="text" name="producto" id="" placeholder="Nombre de Producto" class="formu" required>
<input type="text" name="lote" id="" placeholder="Lote" oninput="this.value = this.value.toUpperCase()" class="formu" required>
<input type="text" name="codigo_barra" id="" placeholder="Código de Barra" oninput="this.value = this.value.toUpperCase()" class="formu" required>
<input type="text" name="precio" id="" placeholder="Precio" class="formu" required oninput="this.value = this.value.replace(/,/g, '.')">
<input type="date" name="caducidad" id="" class="formu" required>
<input type="number" name="cantidad" id="" placeholder="Cantidad" class="formu" required>

<br class="labelspace">

</form>


<div class="addaddbtn">
<?php
session_start();

// Verificar autenticación
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit();
}

// Verificar rol (ejemplo para superadmin)
if ($_SESSION["rol"] === 'superadmin') {
    // Mostrar funcionalidades completas
?> <a href="./newcp.php"><button  class="addcp">Agregar Sector <i class="fa-regular fa-square-plus"></i></button></a>
    <div class="addbtn">
        <button type="reset" value="Limpiar" class="clear" form="ad_form">Limpiar <i class="fa-regular fa-trash-can"></i></button>
        <button type="submit" name="guardado" value="Guardar" class="submit" form="ad_form">Guardar <i class="fa-regular fa-floppy-disk"></i></button>
    </div>


<?php } else {
    // Limitar funcionalidades
?>  <button type="reset" value="Limpiar" class="clear" form="ad_form">Limpiar <i class="fa-regular fa-trash-can"></i></button>
    <button type="submit" name="guardado" value="Guardar" class="submit" form="ad_form">Guardar <i class="fa-regular fa-floppy-disk"></i></button>
<?php }
?>
        
</div>

</center>

<!-- <script src="js/select.js"></script> -->

