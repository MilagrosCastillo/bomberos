<!DOCTYPE html>
<?php
include('dashlayout.php');
$varsector = $_POST['sector'];
?>
<style>
th{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
td{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
</style>

<div class="btn-res-re">
    <a href="sectores.php"><button class="btn-re"><i class="fa-solid fa-arrow-left"></i> Regresar</button></a>
</div>
<div class="btn-pdf-div">
<a href="pdf-resumen.php?sector=<?php echo $varsector;?>" target="_blank"><button class="btn-pdf" name="ver">Descargar Resumen en PDF <i class="fa-solid fa-download"></i></button></a>
</div>

<center>
<table class="tabla">
<thead>
    <tr>
        <th>Sectores</th>
        <th>Producto</th>
        <th>Lote</th>
        <th>Código de Barra</th>
        <th>Precio</th>
        <th>Fecha Caducidad</th>
        <th>Cantidad</th>
        <th>Fecha Registro</th>
        <th>Editar Datos</th>
        <th>Eliminar Datos</th>
    </tr>
</thead>
<tbody>

<?php
include('conexion.php');
if(isset($_POST['ver'])){
    $sector = $_POST['sector'];
    $query = "SELECT * FROM reporte WHERE sector = '$sector'";
    $resultado = mysqli_query($conexion,$query);
    while ($row = mysqli_fetch_array($resultado)) { ?>
        <tr>
            <td><?php echo $row['sector']?></td>
            <td><?php echo $row['producto']?></td>
            <td><?php echo $row['lote']?></td>
            <td><?php echo $row['codigo_barra']?></td>
            <td><?php echo $row['precio']?></td>
            <td><?php echo $row['caducidad'] ?></td>
            <td><?php echo $row['cantidad'] ?></td>
            <td><?php echo $row['fecha'] ?></td>
            <td><a href="edit.php?id=<?php echo $row['id']?>" style="color: #1e3a8a; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-regular fa-pen-to-square" style="font-size: 21px; margin-right: 7px;"></i>Editar</a></td>
            <td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td>
        </tr>
<?php } ?>
<?php } ?>
</tbody>
</table>
</center>

