<?php
include("session.php");
$activa = true;

//error_reporting(0);


include("dashlayout.php");

include("conexion.php");
//include("user.php");

?>

<?phpif(!isset($_SESSION)){session_start();}?>

<center>
<form action="guardadocp.php" method="post" class="ad-form">
    <p class="text-lg">Para agregar un nuevo Centro Popular a la base de datos debe rellenar todos los datos requeridos en el formulario</p>
    <input type="text" class="formu" name="centropopular" id="" placeholder="Nombre Del Centro Popular" oninput="capitalizeInput(this)">
    <br>
    <input type="text" class="formu" name="sector" id="" placeholder="Sector Del Centro" oninput="capitalizeInput(this)">
    <br>
    <input type="text" class="formu" name="municipio" id="" placeholder="Municipio Del Centro" oninput="capitalizeInput(this)">
    <br class="labelspace">
    <div class="addbtn">
        <button type="reset" value="Limpiar" class="clear">Limpiar <i class="fa-regular fa-trash-can"></i></button>
        <button type="submit" name="guardado" value="Guardar" class="submit">Guardar <i class="fa-regular fa-floppy-disk"></i></button>
    </div>
</form>
</center>
<script>
function capitalizeInput(input) {
    // Guardar posición del cursor
    const start = input.selectionStart;
    const end = input.selectionEnd;
    
    // Transformar el texto
    input.value = input.value.toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    
    // Restaurar posición del cursor
    input.setSelectionRange(start, end);
}
</script>
