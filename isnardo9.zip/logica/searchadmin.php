<center>
<table class="tabla">
<thead>
    <tr>
        <th>Sectores</th>
        <th>Producto</th>
        <th>Lote</th>
        <th>Código de Barra</th>
        <th>Precio</th>
        <th>Fecha Caducidad</th>
        <th>Cantidad</th>
        <th>Fecha Registro</th>
    </tr>
</thead>
<tbody>
<?php
if(isset($_GET['search'])){
    $search = mysqli_real_escape_string($conexion, $_GET['busqueda']);
    
    $query = "SELECT * FROM reporte WHERE 
        sector LIKE '%$search%' OR 
        producto LIKE '%$search%' OR 
        lote LIKE '%$search%' OR 
        codigo_barra LIKE '%$search%' OR 
        precio LIKE '%$search%' OR 
        caducidad LIKE '%$search%' OR 
        cantidad LIKE '%$search%' 
        ORDER BY fecha DESC";
        
    $resultado = mysqli_query($conexion, $query);
    
    if(mysqli_num_rows($resultado) > 0) {
        while ($row = mysqli_fetch_array($resultado)) { ?>
            <tr>
                <td><?php echo $row['sector']?></td>
                <td><?php echo $row['producto']?></td>
                <td><?php echo $row['lote']?></td>
                <td><?php echo $row['codigo_barra']?></td>
                <td><?php echo $row['precio']?></td>
                <td><?php echo $row['caducidad'] ?></td>
                <td><?php echo $row['cantidad'] ?></td>
                <td><?php echo $row['fecha'] ?></td>
            </tr>
        <?php }
    } else { ?>
        <tr>
            <td colspan="10" class="py-4 text-gray-500">
                No se encontraron resultados para "<?php echo htmlspecialchars($_GET['busqueda']) ?>"
            </td>
        </tr>
    <?php }
}
?>
</tbody>
</table>
</center>



