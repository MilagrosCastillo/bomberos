<?php

include('conexion.php');
include('session.php');
include('dashlayout.php');

if (isset($_POST['create'])) {
    if ($_POST['usuario'] == 'admin@admin') {
        echo '<script>alert ("Error, No puedes crear un usuario identico al SuperAdministrador");</script>';
    } else {
        $usuario = trim($_POST['usuario']);
        $password_plain = $_POST['password']; // Contraseña en texto plano desde el formulario

        $query = "SELECT usuario FROM usuarios WHERE usuario = ?";
        $stm = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stm, "s", $usuario);
        mysqli_stmt_execute($stm);
        mysqli_stmt_store_result($stm);
        if (mysqli_stmt_num_rows($stm)>0) {
            echo '<script>alert("Error, el usuario que esta creando ya existe");</script>';
        } else {
                // Encriptar la contraseña antes de guardarla en la base de datos
                $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);
                
                $query2 = "INSERT INTO usuarios (usuario, password) VALUES (?, ?)";
                $stmt2 = mysqli_prepare($conexion, $query2);
                mysqli_stmt_bind_param($stmt2, "ss", $usuario, $password_hashed);
                mysqli_stmt_execute($stmt2);
                
                if (mysqli_stmt_affected_rows($stmt2) > 0) {
                    $_SESSION['usuario'] = $usuario; // Actualizar la sesión con el nuevo nombre de usuario
                    printf('<script> alert("Nueno Administrador creado correctamente");</script>');
                } else {
                    echo "Error al actualizar la configuración.";
                }
        }
    }
}


?>
<style>
th{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
td{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
</style>

<div class="adduser">
    <form method="post" action="adduser.php" class="adduserform">
        <label for="">Nombre del Nuevo Usuario:</label>
        <input type="text" name="usuario" placeholder="Ejemplo: asicmiranda">
        <label for="">Contraseña para el Nuevo Usuario:</label>
        <input type="password" name="password" id="pass">
        <span id="view" style="display: block; cursor: pointer;"><i class="fa-solid fa-eye"></i> Ver Contraseña Escrita</span>
        <span id="notview" style="display: none; cursor: pointer;"><i class="fa-solid fa-eye-slash"></i> Ver Contraseña Escrita</span>
        <div class="editdeletbtn" style="margin-top: 21px;">
            <button type="reset" class="clear">Limpiar</button>
            <button type="submit" name="create" class="submit">Guardar</button>
        </div>
    </form>
</div>

<center class="mt-9">
<table class="tabla">
<thead>
    <tr>
        <th>Usuario</th>
        <th>Tipo de Administrador</th>
        <th>Editar Datos</th>
      <!--  <th>Eliminar Datos</th>-->
    </tr>
</thead>
<tbody>
<?php
$query = "SELECT * FROM usuarios WHERE rol != 'superadmin'";
$resultado = mysqli_query($conexion, $query);

while ($row = mysqli_fetch_array($resultado)) { ?>
    <tr>
        <td><?php echo $row['usuario'] ?></td>
        <td><?php echo $row['rol'] ?></td>
        <td><a href="edit-user.php?id_usuarios=<?php echo $row['id_usuarios']?>" style="color: #1e3a8a; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-regular fa-pen-to-square" style="font-size: 21px; margin-right: 7px;"></i>Editar</a></td>
        <!--<td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td> -->
    </tr>
    <?php } ?>
</tbody>
</table>
</center>


<script src="./js/vew.js"></script>
<script src="./js/tilwind-3-4-3.js"></script>
