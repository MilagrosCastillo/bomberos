let inputPass = document.getElementById('password');
let btnPass = document.querySelector('.passbtn');
let btnPassHidden = document.querySelector('.passbtnhidde');

btnPass.addEventListener('click', () => {
    inputPass.type="text";
    btnPass.classList.add('hid');
    btnPassHidden.classList.remove('hid');
});
btnPassHidden.addEventListener('click', () => {
    inputPass.type="password";
    btnPass.classList.remove('hid');
    btnPassHidden.classList.add('hid');
});
