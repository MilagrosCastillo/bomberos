let ver = document.getElementById('view');
let ocul = document.getElementById('notview');
let cont = document.getElementById('pass');

ver.addEventListener('click', ()=>{
    cont.type = 'text';
    ver.style.display = 'none';
    ocul.style.display = 'block'
});
ocul.addEventListener('click', ()=>{
    cont.type = 'password';
    ocul.style.display = 'none';
    ver.style.display = 'block';
})

