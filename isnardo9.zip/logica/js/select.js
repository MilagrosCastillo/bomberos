// alert("hola")
let muni = document.querySelector('#miranda');
let andres = document.querySelector('#ab-sele');
let mi = document.querySelector('#mi');
let ab = document.querySelector('#ab');
let to = document.querySelector('#all');
// -----
// let consul = document.querySelector('.consult');
// let miAd = document.querySelector('.mi-ad');
// let abAd = document.querySelector('.ab-ad');
// let mirad = document.querySelector('.mirad');
// let abad = document.querySelector('.abad');

// mi.addEventListener('click', () => {
//     muni.style.display = "block";
//     ab.style.display = "none";
// });
// andres.addEventListener('click', () => {
//     ab.style.display = 'block';
//     muni.style.display = 'none';
//     alert('hola')
// });

// to.addEventListener('click', () => {
//     muni.style.display = 'none';
//     ab.style.display = 'none';
// });

// // ------

// miAd.addEventListener('click', () => {
//     mirad.style.display = 'block';
//     abad.style.display = 'none';
// });
// abAd.addEventListener('click', () => {
//     abad.style.display = 'block';
//     mirad.style.display = 'none';
// });

// consul.addEventListener('click', () => {
//     abad.style.display = 'none';
//     mirad.style.display = 'none';
// });

let list = document.getElementsByClassName('municipio').value;

if (list === "all") {
    muni.style.display = "none";
    ab.style.display = "none";
} else {
    
}
