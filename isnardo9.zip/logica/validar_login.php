<?php 
session_start();
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["btningresar"])) {
    if (isset($_POST["usuario"]) && isset($_POST["password"])) {
        $usuario = trim($_POST["usuario"]);
        $contra = trim($_POST["password"]);

        // Validar campos vacíos
        if (empty($usuario) || empty($contra)) {
            header("location:login.php?error=emptyfields");
            exit();
        }

        // Modificamos la consulta para incluir el rol
        $consulta = $conexion->prepare("SELECT usuario, password, rol FROM usuarios WHERE BINARY usuario = ?");
        $consulta->bind_param("s", $usuario);
        $consulta->execute();
        $resultado = $consulta->get_result();

        if ($fila = $resultado->fetch_assoc()) {
            if (password_verify($contra, $fila['password'])) {
                // Almacenar rol en sesión
                $_SESSION["usuario"] = $usuario;
                $_SESSION["rol"] = $fila['rol'];  // <- Nueva línea clave
                
                header("location:dashboard.php");
                exit();
            } else {
                // header("location:login.php");
                echo '<script>alert("Error al validar los datos"); history.back();</script>';
                exit();
            }
        } else {
            header("location:login.php");
            exit();
        }

        $consulta->close();
    } else {
        header("location:login.php");
        exit();
    }
} else {
    header("location:login.php");
    exit();
}
?>

