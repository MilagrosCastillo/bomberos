<?php 

include("conexion.php");
include("session.php");

include("user.php");

$varusuario = $_SESSION["usuario"];
$head = "<div class='mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8'><center><h1 class='text-3xl font-bold tracking-tight text-gray-900'>Bienvenido $varusuario al Resumen</h1></center></div>";
$activa1 = true;
include('dashlayout.php');

?>
<style>

th{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}
td{
    padding: 21px;
    border: 1px solid;
    text-align: center;
}


</style>
<div class="btn-pdf-div">
    <a href="pdf.php"target="_blank"><button class="btn-pdf">Descargar Informe Completo en PDF <i class="fa-solid fa-download"></i></button></a>
</div>

<?php
session_start();

// Verificar autenticación
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit();
}

// Verificar rol (ejemplo para superadmin)
if ($_SESSION["rol"] === 'superadmin') {
    // Mostrar funcionalidades completas
    include('reporte-vista-superadmin.php');
} else {
    // Limitar funcionalidades
    include('reporte-vista-admin.php');
}
?>

