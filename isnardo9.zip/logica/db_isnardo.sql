create database db_isnardo;

use db_isnardo;
drop database db_isnardo;

CREATE TABLE `usuarios` (
  `id_usuarios` int(11) primary key auto_increment NOT NULL,
  `usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'admin',
  check(rol in('superadmin','admin'))
);

INSERT INTO `usuarios` (`id_usuarios`, `usuario`, `password`, `rol`) VALUES (1, 'admin@admin', '$2y$10$vHLI6IsjMif2FwhQaLzqHegmur3W6g3RnNpJMCWgVHzIRNf1MzOnW', 'superadmin');
-- (2, 'Coordinadora', 'Milagros');

create table reporte(
	id int primary key auto_increment not null,
    sector varchar(255) not null,
    producto varchar(255) not null,
    lote varchar(255) not null,
    codigo_barra varchar(255) not null,
    precio decimal(10, 2) not null,
    caducidad varchar(255) not null,
    cantidad numeric not null,
    fecha timestamp
);

create table sectores (
	id int primary key auto_increment not null,
    centropopular varchar(255) not null,
    sector varchar(255) not null,
    municipio varchar(255) not null
);
