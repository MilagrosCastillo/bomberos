<?php
include('conexion.php');
include("user.php");
include('session.php');

if (isset($_GET['id_usuarios'])) {
    $id = $_GET['id_usuarios'];
    $query = "SELECT * FROM usuarios WHERE id_usuarios = $id";
    $result = mysqli_query($conexion, $query);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $usuario = $row['usuario'];
        $rol = $row['rol'];
    }
}
if (isset($_POST['guardar'])) {
    $id = $_GET['id_usuarios'];
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Solo actualiza la contraseña si se proporcionó una nueva
    if (!empty($password)) {
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);
        $query = "UPDATE usuarios SET usuario = '$usuario', password = '$password_hashed' WHERE id_usuarios = $id";
    } else {
        $query = "UPDATE usuarios SET usuario = '$usuario' WHERE id_usuarios = $id";
    }

    if (mysqli_query($conexion, $query)) {
        header('Location: dashboard.php');
        exit(); // Asegura que el script termine después de la redirección
    } else {
        echo "Error al actualizar: " . mysqli_error($conexion);
    }
}include('dashlayout.php');
?>

<form action="edit-user.php?id_usuarios=<?php echo $id; ?>" method="POST"  class="ad-form">
<br class="labelspace">
<label for="usuario">Nombre de Usuario:</label>
<input type="text" name="usuario" id="" placeholder="Nombre de Usuario" class="formu" value="<?php echo $usuario; ?>">

<br class="labelspace">
<label for="lote">Rol:</label>
<span id="" placeholder="Rol" class="formu bg-white text-gray-500 italic" value=""><?php echo $rol; ?></span>
<br class="labelspace">
<label for="usuario">Contraseña del Usuario:</label>
<input type="password" name="password" id="" placeholder="Contraseña del Usuario" class="formu">

<br class="labelspace">


<br class="salto">

<div class="editdeletbtn">
<td><a href="delete.php?id_usuarios=<?php echo $row['id_usuarios']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td>
    <div class="editbtn">
        <!--<td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td> -->
        <input type="submit" name="guardar" value="Guardar" class="submit">
        <button type="button" onclick="history.back()" style="background-color: #f00; color: #fff; padding: 7px; border-radius: 7px; font-weight: 700;" >Cancelar</button>
    </div>
</div>
</form>
<script src="./js/tilwind-3-4-3.js"></script>
