<?php 

//session_start();

//include("user.php");

$conexion = mysqli_connect("localhost","root","","db_isnardo");

/* if(!$conexion){ */

/*     echo "No se pudo conectar a la base de datos"; */
/* }else{ */
/*     echo "La conexion ha sido exitosa :)"; */
/* } */


?>
