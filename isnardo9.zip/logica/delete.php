<?php

include("dashlayout.php");

include("conexion.php");
include("user.php");

if (isset($_GET['id_usuarios'])) {
    $id = $_GET['id_usuarios'];
    $query = "DELETE FROM usuarios WHERE id_usuarios = $id";
    $result = mysqli_query($conexion, $query);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminando Información</title>
    <link rel="stylesheet" href="./css/estilo.css">
</head>
<body>
<center class="delete-center-section">
    <h1 style="font-weight: 600;font-style: normal;color: #00b53e;font-size: 70px;margin-bottom: 30px;"><i class="fa-solid fa-check"></i></h1>
    <h1>Información Eliminada Correctamente</h1>
    <a href="dashboard.php"><button class="delete-button">Volver al Inicio</button></a>
</center>
</body>
</html>
