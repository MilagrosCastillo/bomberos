<?php

include("dashlayout.php");
include('conexion.php');
include("user.php");

if (!is_null($_POST['guardado'])){
    /* echo 'guardando...'; */
    $sector = $_POST['sector'];
    $producto = $_POST['producto'];
    $lote = $_POST['lote'];
    $codigo_barra = $_POST['codigo_barra'];
    $precio = $_POST['precio'];
    // Verifica si hay comas
    if (strpos($precio, ',') !== false) {
        $_SESSION['error'] = "Error: Usa punto (.) para decimales.";
        header("Location: dashboard.php"); // Redirige al formulario
        exit();
    }
    $caducidad = $_POST['caducidad'];
    $cantidad = $_POST['cantidad'];
    $fecha = $_POST['fecha'];
    echo $lista;

    $query = "INSERT INTO reporte(sector,producto,lote,codigo_barra,precio,caducidad,cantidad) VALUES ('$sector','$producto','$lote','$codigo_barra','$precio','$caducidad','$cantidad')";
    $result = mysqli_query($conexion, $query);

    /* $_SESSION['message'] = 'Tarea Realizada'; */
    /* $_SESSION['message_type'] = 'Correcto'; */

    // header("Location: sectores.php");
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guardando Información</title>
    <link rel="stylesheet" href="./css/estilo.css">
</head>
<body>
<center class="delete-center-section">
    <h1 style="font-weight: 600;font-style: normal;color: #00b53e;font-size: 70px;margin-bottom: 30px;"><i class="fa-solid fa-check"></i></h1>
    <h1>Información Guardada Correctamente</h1>
    <a href="dashboard.php"><button class="delete-button">Volver al Inicio</button></a>
</center>
</body>
</html>
