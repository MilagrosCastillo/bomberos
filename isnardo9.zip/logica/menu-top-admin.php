<div class="min-h-full">
  <nav class="bg-blue-900" style="padding-top: 21px; padding-bottom: 21px;">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="flex h-16 items-center justify-between">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <a href="dashboard.php" class="cursor-pointer" title="Ir al resumen"><img class="h-20 hover:brightness-200 hover:drop-shadow-[0_0_2px_rgba(253,243,5,0.7)] transition-all" src="img/logo.png" alt="Your Company"></a>
          </div>
          <div class="hidden md:block">
            <div class="ml-10 flex items-baseline space-x-4">
              <a class="text-white hover:bg-blue-700 rounded-md px-3 py-2 text-lg font-medium cursor-pointer" onclick="history.back()" title="Regresar a la vista anterior"><i class="fa-solid fa-arrow-left"></i></a>

              <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
              <a href="dashboard.php"   class="<?= $currentpage == 'dashboard.php' ? 'bg-white text-black' : 'text-white hover:bg-blue-700'?> rounded-md px-3 py-2 text-sm font-medium">Resumen</a>
              <a href="sectores.php"   class="<?= $currentpage == 'sectores.php' ? 'bg-white text-black' : 'text-white hover:bg-blue-700'?> rounded-md px-3 py-2 text-sm font-medium">Consultorios</a>
              <a href="search.php" style="margin-left: 150%;" class="<?= $currentpage == 'search.php' ? 'bg-white text-black' : 'text-white hover:bg-blue-700'?> rounded-md px-3 py-2 text-xl font-medium" title="Realizar busqueda"><i class="fa-solid fa-magnifying-glass"></i></a>
              <a href="config.php" class="<?= $currentpage == 'config.php' ? 'bg-white text-black' : 'text-white hover:bg-blue-700'?> rounded-md px-3 py-2 text-xl font-medium" title="Configuración"><i class="fa-solid fa-gear"></i></a>
              <a href="cerrar_sesion.php" class="rounded-md px-3 py-2 text-xl font-medium text-white hover:bg-blue-700" title="Cerrar Sesión"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
          </div>
        </div>
       </div>
    </div>
</nav>

  <header class="bg-white shadow">
  <?= isset($head) ? $head : '';?>
  </header>
  <main>
    <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <!-- Your content -->
    <?= isset($contenido) ? $contenido : '';?>
    </div>
  </main>
</div>
