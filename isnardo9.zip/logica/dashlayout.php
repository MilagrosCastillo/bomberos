<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Administrador</title>
    <link rel="stylesheet" href="css/estilo.css">
    <script src="js/tilwind-3-4-3.js"></script>
    <link rel="shortcut icon" href="img/logo.png">
    <script src="https://kit.fontawesome.com/59b6007b3d.js" crossorigin="anonymous"></script>
</head>
<body>
<?php $currentpage = substr($_SERVER['SCRIPT_NAME'], strrpos($_SERVER['SCRIPT_NAME'],"/")+1);?>	

<!--
  This example requires updating your template:

  ```
  <html class="h-full bg-gray-100">
  <body class="h-full">
  ```
-->
<?php
error_reporting (0);
session_start();

// Verificar autenticación
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit();
}

// Verificar rol (ejemplo para superadmin)
if ($_SESSION["rol"] === 'superadmin') {
    // Mostrar funcionalidades completas
    include('menu-top-superadmin.php');
} else {
    // Limitar funcionalidades
    include('menu-top-admin.php');
}
?>

<script src="js/close.js"></script>

</body>
</html>
