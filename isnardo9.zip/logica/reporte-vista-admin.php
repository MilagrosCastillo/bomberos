<center>
<table class="tabla">
<thead>
    <tr>
        <th>Sectores</th>
        <th>Producto</th>
        <th>Lote</th>
        <th>Código de Barra</th>
        <th>Precio</th>
        <th>Fecha Caducidad</th>
        <th>Cantidad</th>
        <th>Fecha Registro</th>
      <!--  <th>Eliminar Datos</th>-->
    </tr>
</thead>
<tbody>
<?php
$query = "SELECT * FROM reporte";
$resultado = mysqli_query($conexion, $query);

while ($row = mysqli_fetch_array($resultado)) { ?>
    <tr>
        <td><?php echo $row['sector'] ?></td>
        <td><?php echo $row['producto'] ?></td>
        <td><?php echo $row['lote'] ?></td>
        <td><?php echo $row['codigo_barra'] ?></td>
        <td><?php echo $row['precio'] ?></td>
        <td><?php echo $row['caducidad'] ?></td>
        <td><?php echo $row['cantidad'] ?></td>
        <td><?php echo $row['fecha'] ?></td>
        <!--<td><a href="delete.php?id=<?php echo $row['id']?>" style="color: #b50000; padding: 7px; border-radius: 7px; font-weight: 600; text-decoration: underline;"><i class="fa-solid fa-trash" style="font-size: 21px; margin-right: 7px;"></i>Eliminar</a></td> -->
    </tr>
    <?php } ?>
</tbody>
</table>
</center>

