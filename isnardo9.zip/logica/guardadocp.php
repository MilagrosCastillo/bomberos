<?php

include("dashlayout.php");
include('conexion.php');
include("user.php");

if (!is_null($_POST['guardado'])){
    /* echo 'guardando...'; */
    $centropopular = $_POST['centropopular'];
    $sector = $_POST['sector'];
$municipio = $_POST['municipio'];

    $query = "INSERT INTO sectores(centropopular,sector,municipio) VALUES ('$centropopular','$sector','$municipio')";
    $result = mysqli_query($conexion, $query);

    /* $_SESSION['message'] = 'Tarea Realizada'; */
    /* $_SESSION['message_type'] = 'Correcto'; */
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guardando Información</title>
    <link rel="stylesheet" href="./css/estilo.css">
</head>
<body>
<center class="delete-center-section">
    <h1 style="font-weight: 600;font-style: normal;color: #00b53e;font-size: 70px;margin-bottom: 30px;"><i class="fa-solid fa-check"></i></h1>
    <h1>Información Guardada Correctamente</h1>
    <a href="dashboard.php"><button class="delete-button">Volver al Inicio</button></a>
</center>
</body>
</html>
