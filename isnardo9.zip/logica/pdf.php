<?php
require('fpdf/fpdf.php');

/* if (isset($_GET[''])) { */
    /* $id = $_GET['id']; */
/* } */

class PDF extends FPDF{
function ChapterTitle($in, $in2, $title, $in3, $in4, $in5){
    // Color de fondo
    $this->SetFillColor(200,220,255);
    // Título
    $this->Cell($in,$in2,"$title",$in3,$in4,"$in5",true);
}
function PrintChapter($in, $in2, $title, $in3, $in4, $in5){
    $this->ChapterTitle($in, $in2, $title, $in3, $in4, $in5);
}
function Header()
{
    $this->SetFont('Arial','B', 21);
    $this->Cell(0,10, utf8_decode('Area de Salud Integral Comunitaria ASIC MIRANDA, Estado Trujillo'),0,0,'C',0,0);
    $this->Image('img/logodark.png', 12, 8, 15);
    $this->Ln(20);
    $this->SetFont('Arial', '', 10);
    $this->PrintChapter(50,10,'Sectores',1,0,'C');
    $this->PrintChapter(80,10,'Producto',1,0,'C');
    $this->PrintChapter(30,10,'Lote',1,0,'C');
    $this->PrintChapter(30,10,'Vence',1,0,'C');
    $this->PrintChapter(30,10,'Cod. Barras',1,0,'C');
    $this->PrintChapter(30,10,'Precio U.',1,0,'C');
    $this->PrintChapter(25,10,'Cant',1,0,'C');
    $this->Ln();
}
function Footer()
    {
        $this->SetY(-20);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Pagina '.$this->PageNo(),0,0,'C');
    }
}




$pdf = new PDF();
$pdf->__construct('L');
$pdf->AddPage();
/* $pdf->SetY(15); */


/* $conexion = mysqli_connect("localhost","root","","db_isnardo"); */
include('conexion.php');
$query = "SELECT * FROM reporte";
$result = mysqli_query($conexion, $query);

/* $pdf->Cell(50,10,'Sectores',1,0,'C'); */
/* $pdf->Cell(80,10,'Producto',1,0,'C'); */
/* $pdf->Cell(30,10,'Lote',1,0,'C'); */
/* $pdf->Cell(30,10,'Vence',1,0,'C'); */
/* $pdf->Cell(30,10,'Cod. Barras',1,0,'C'); */
/* $pdf->Cell(30,10,'Precio U.',1,0,'C'); */
/* $pdf->Cell(25,10,'Cant',1,0,'C'); */
/* $pdf->Ln(); */

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(50,10,$row['sector'],1,0,'C',0);
    $pdf->Cell(80,10,$row['producto'],1,0,'C',0);
    $pdf->Cell(30,10,$row['lote'],1,0,'C',0);
    $pdf->Cell(30,10,$row['caducidad'],1,0,'C',0);
    $pdf->Cell(30,10,$row['codigo_barra'],1,0,'C',0);
    $pdf->Cell(30,10,$row['precio'],1,0,'C',0);
    $pdf->Cell(25,10,$row['cantidad'],1,0,'C',0);
    $pdf->Ln();
}


$pdf->Output();
?>

