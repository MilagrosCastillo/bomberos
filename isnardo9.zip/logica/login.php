<!DOCTYPE html>
<html lang="es">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <link rel="stylesheet" href="css/bootstrap.css">
   <link rel="stylesheet" type="text/css" href="css/style_.css">
   <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
   <!-- <link rel="stylesheet" href="css/all.min.css"> -->
   <!-- <link rel="stylesheet" href="css/fontawesome.min.css"> -->
   <link href="img/logo.png" rel="shortcut icon">
    <script src="https://kit.fontawesome.com/59b6007b3d.js" crossorigin="anonymous"></script>

   <title>Inicio de sesión</title>
</head>

<body class="background">

<div class="loginandimg">

<!--<img src="./img/enfermera.jpg" alt="" class="imglogin">-->

    <div class="login-contentdos">
        <form method="post" action="validar_login.php" class="formlogin">
            <img src="./img/logo2.png" class="logoimg" alt="" srcset="">
            <!--<h2 class="title">BIENVENIDOS</h2>-->
            <h5 class="la">Usuario</h5>
            <input id="usuario" type="text" class="pr-24 border-gray-300 block mt-1 w-full input" name="usuario">
            <h5 class="la">Contraseña</h5>
        <div class="">
        <div class="relative">
            <input type="password" id="password" class="pr-24 border-gray-300 block mt-1 w-full input" name="password">
            <!--<input type="checkbox" onclick="pw.type = this.checked ? 'text' : 'password'">-->
            <button type="button" class="passbtn font-sans bg-gray-200 text-sm text-gray-600 hover:text-gray-900 absolute rounded-md right-px top-1/2 -translate-y-1/2 p-3.5"><i class="fa-regular fa-eye"></i> Mostrar</button>
            <button type="button" class="passbtnhidde hid font-sans bg-gray-200 text-sm text-gray-600 hover:text-gray-900 absolute rounded-md right-px top-1/2 -translate-y-1/2 p-3.5"><i class="fa-regular fa-eye-slash"></i> Ocultar</button>
            <script src="js/show.js"></script>
        </div>
        </div>
                        <!--<div class="text-center">
               <a class="font-italic isai5" href="">Olvidé mi contraseña</a>
               <a class="font-italic isai5" href="">Registrarse</a>
            </div>-->
            <input name="btningresar" class="btn" type="submit" value="INICIAR SESION">
        </form>
    </div>

</div>   

   <script src="js/fontawesome.js"></script>
    <script src="js/tilwind-3-4-3.js"></script>
   <script src="js/main.js"></script>
   <script src="js/main2.js"></script>
   

</body>

</html>
